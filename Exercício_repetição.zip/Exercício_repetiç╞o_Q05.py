n = int(input("Digite um número positivo: "))
num = n

while (num > 0):
    print(f" {num} ")
    num = num - 1

print("Fim do programa")