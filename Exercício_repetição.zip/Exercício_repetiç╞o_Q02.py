num = 1

while (num <= 1000):
    print(f" {num} ")
    num = num + 1

print("Fim do programa")