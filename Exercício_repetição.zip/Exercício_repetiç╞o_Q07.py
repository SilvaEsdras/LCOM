num = 0
n = int(input("Digite um número maior que 5: "))

if n <= 5:
    print("O número precisa ser maior do que 5.")
else:
    while (num <= n):
        if num % 5 == 0:
            print(f" {num} ")
        num = num + 1

print("Fim do programa")