num = 1000

while (num > 0):
    print(f" {num} ")
    num = num - 1

print("Fim do programa")