num = 0

while num != 1:
    num = int(input("Digite o número 1: "))

print("Fim do Programa")
