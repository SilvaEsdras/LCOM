num = 1

while (num <= 100):
    if num % 3 == 0:
        print(f" {num} ")
    num = num + 1

print("Fim do programa")
