num = 0
n = int(input("Digite um número maior que 5: "))

if n <= 1:
    print("O número precisa ser maior do que 5.")
else:
    i = 1
    while (i <= n):
        if i % 2 == 0:
            num = num + 1
        i = num + 1
    print(f"Total de números pares entre 1 e {n} : {num} ")

print("Fim do programa")


#count = 0
#n = int(input("Digite um número maior do que 1: "))

#if n <= 1:
#    print("O número precisa ser maior do que 1.")
#else:
#    i = 1
#    while i <= n:
#        if i % 2 == 0:
#            count += 1
#        i += 1
#    print("Total de números pares entre 1 e", n, ":", count)
