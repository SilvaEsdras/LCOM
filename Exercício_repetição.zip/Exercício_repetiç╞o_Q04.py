num = 1
n = int(input("Digite um número positivo: "))

while (num <= n):
    print(f" {num} ")
    num = num + 1

print("Fim do programa")