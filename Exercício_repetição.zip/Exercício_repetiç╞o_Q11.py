num = int(input("Digite um valor inteiro positivo: "))

if num <= 0:
    print("O valor precisa ser um número inteiro positivo.")
else:
    count = 0
    while count < 6:
        if num % 2 != 0:
            print(num)
            count += 1
        num += 1
