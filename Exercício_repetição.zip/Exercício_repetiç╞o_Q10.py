num = int(input("Digite um valor inteiro (5 < N < 2000): "))

if num <= 5 or num >= 2000:
    print("O valor de N precisa estar no intervalo entre 5 e 2000.")
else:
    i = 1
    while i <= num:
        if i % 2 == 0:
            quadrado = i ** 2
            print(f"{i} ^ 2 = {quadrado}")
        i += 1
