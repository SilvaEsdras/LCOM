nome = 0

while (nome < 100):
    print("Esdras Silva")
    nome = nome + 1
    
print("Fim do programa")