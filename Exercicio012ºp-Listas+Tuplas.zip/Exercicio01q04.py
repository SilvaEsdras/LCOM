num = [10, 9, 8, 7, 6]	#lista

num[0], num[4] = num[4], num[0]		#Troca dos valores
num[1], num[3] = num[3], num[1]		#Troca dos valores

#Exibições
print("Sua lista é ", num)