num = [7, 8, 9, 5, 6]	#lista
print("Sua lista é ", num)

num[2] = int(input("Digite um novo numero para alterar o 2º elemento: "))		#Alterando o valor do 2º
soma = num[0]+num[1]+num[2]+num[3]	#Calculando a soma das notas

#Exibições
print("Sua lista atualizada é: ", num)
print("O último elemento é: ", num[4])
print("O primeiro elemento é: ", num[0])
print("A soma dos elementos é: ", soma)
