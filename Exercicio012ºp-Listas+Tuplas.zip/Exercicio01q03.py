num = [10, 9, 8]	#lista

if num[0] > num[1]:		#verificação se o elemento 1 é maior que o 2.
    num[0], num[1] = num[0], num[1]		#Alterando os valores
    print(num)	#Exibições
if num[1] > num[2]:
    num[1], num[2] = num[2], num[1]
    print(num)	#Exibições

#Exibições
print("Sua lista é ", num)