notas = [7.0, 8.5, 9.3, 7.9]	#lista

notas[2] = 7.8		#Alterando o valor do 2º
soma = notas[0]+notas[1]+notas[2]+notas[3]	#Calculando a soma das notas
media = soma / 4 #Calculando a média da notas

#print(notas[2])	Apenas verificando o 2º valor

#Exibições
print(notas[3])
print("A soma das notas é: ", soma)
print("A media das notas é: ", media)