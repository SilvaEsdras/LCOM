# Questão 0a (Exemplo):
# Crie e execute uma função que receba dois números inteiros , como
# parâmetros, e retorne a soma entre esse dois.

# def soma(a,b):
#     return a+b

# num1 = int(input("Digite um numero:"))
# num2 = int(input("Digite outro numero:"))

# resposta = soma(num1,num2)
# print("Soma = %d" %(resposta))

# Questão 0b (Exemplo):
# Crie e execute uma função que receba um número inteiro como parâmetro e
# retorne True caso ele seja positivo e False caso ele seja negativo.

# def ehPositivo(num):
#     if(num<0 ):
#         return False
#     else:
#         return True
# a = int(input("Digite um número:"))
# if (ehPositivo(a)):
#     print("Positivo")
# else:
#     print("Negativo")

# Questão 1
# Crie e execute uma função que receba, como parâmetro, um número inteiro e
# retorna True caso o número seja par e False caso contrário. Por fim, utilizando
# a função criada, crie um programa que receba um número e exiba se ele é par ou ímpar.

def par_impar(num):
    if num % 2 == 0:
        return True
    else:
        return False

n = int(input("Digite um número: "))
if(par_impar(n)):
    print(f'O número {n} é par')
else:
    print(f'O número {n} é impar')

# Questão 2
# Crie e execute uma função que receba, como parâmetro, um número e retorne
# seu sucessor.

def sucessor(numero):
    return numero + 1

numero = int(input("Digite um número: "))
print(sucessor(numero))

# Questão 3
# Crie e execute uma função que receba, como parâmetro, dois números e
# retorne o maior deles.

def maior(a,b):
    if a > b:
        return a
    else:
        return b

a = int(input("Digite o 1º número: "))
b = int(input("Digite o 2º número: "))

resultado = maior(a,b)
print(resultado)

# Questão 4
# Crie e execute uma função que receba, como parâmetro, a media de um aluno
# e imprima na tela se ele estar aprovado, reprovado ou de prova final.
# Atenção: essa função não tem retorno, ela apenas imprime a mensagem e acaba.

def mediaAluno(media):
    if media >= 7.0:
        print('Aprovado')
    elif media <= 5:
        print('Reprovado')
    else:
        print('Prova Final')

media = float(input("Digite a média do aluno: "))
mediaAluno(media)

# Questão 5
# Crie e execute uma função que receba, como parâmetro, a massa e a altura de
# uma pessoa e retorne o seu IMC.

def imc(massa, altura):
    return massa/pow(altura, 2)

massa = float(input("Massa: "))
altura = float(input("Altura: "))

result_imc = imc(massa, altura)

print(f'{result_imc:.2f}')

# Questão 6
# Crie e execute uma função que receba, como parâmetro, o lado (l) de um
# quadrado e retorne sua área.

def areaDoQuadrado(lado):
    return pow(lado , 2)

print(areaDoQuadrado(15))

# Questão 7
# Crie e execute uma função que receba, como parâmetro, a base e a altura de
# um triângulo e retorne sua área (A = (base x altura)/2).

def areaDoTriangulo(base, altura):
    area = (base * altura) / 2
    return area

print(areaDoTriangulo(20, 1.75))