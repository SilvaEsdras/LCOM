necessidade_especiais = False

print(f" {necessidade_especiais}")