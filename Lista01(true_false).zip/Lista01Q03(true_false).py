idade = 25
eleitor =  True

