idade = 25
masculino = True

print(f" {masculino}")