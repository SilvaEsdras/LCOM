nome = str(input("Digite o seu nome: "))

for i in range(100):
    print(nome)