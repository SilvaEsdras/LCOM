quantidade = int(input("Quantas vezes repita o seu nome : "))
num = 0

for i in range(num,quantidade):
    num =+ 1
    print("Esdras Silva")