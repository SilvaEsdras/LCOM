num = int(input("Digite um número positivo: "))
quantidade = 0

for i in range(quantidade, num):
    quantidade = quantidade + 1
    print(quantidade)