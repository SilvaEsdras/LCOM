num = 0

for i in range(0,1000):
    num = num + 1
    print(num)
