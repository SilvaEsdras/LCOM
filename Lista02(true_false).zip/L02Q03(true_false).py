media = float(input("Digite a sua média: "))
aprovado = (media >= 7.0)

print(f" Parabéns!! Você foi aprovado. {aprovado}")
