salario = float(input("Digite o seu salario: "))
imposto = (salario > 1300.80)

#imposto_renda = 

print(f"Declara imposto de renda {imposto}")