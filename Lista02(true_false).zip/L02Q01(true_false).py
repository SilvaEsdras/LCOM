idade = int(input("Digite sua idade: "))
eleitor = (idade >=17)

print(f"Tirar titulo {eleitor}")