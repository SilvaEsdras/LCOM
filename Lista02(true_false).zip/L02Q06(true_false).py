ano = int(input("Digite o ano do carro: "))
valor = float(input("Digite o valor do carro: "))

ipva = (ano > 1990) and (valor > 30900.90)

print(f" Você vai pagar IPVA? {ipva}")