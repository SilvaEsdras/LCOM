a = 100
b = 150
c = True
d = False

valor_final = a > b and c or d

print(f" O valor final é: {valor_final}")