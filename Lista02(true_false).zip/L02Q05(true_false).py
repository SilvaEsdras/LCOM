media = float(input("Digite a média do aluno: "))
total_faltas = int(input("Digite o total de faltas do aluno: "))

aprovado = (media >= 7.0) and (total_faltas < 15)

print(f" Você foi Aprovado? {aprovado}")