#Crie uma matriz 5 x4 de float simulando as notas de uma turma na qual as
#colunas representas os alunos e as linhas representam as provas realizadas
#pela turma
notas = [
        [9.0, 7.5, 8.5, 7.0],
        [5.5, 10.0, 9.0, 6.0],
        [8.3, 9.1, 10.0, 9.5],
        [7.2, 6.2, 8.5, 9.1],
        [10.0, 7.3, 9.5, 8.2]
]

print("Questão 1", notas)

print("\nQuestão 2")
#a) Exiba a nota da que o 1ª aluno tirou na 2ª prova.
print("Letra A \n", notas[0][1])

#b) Exiba a nota da que o 2ª aluno tirou na 3ª prova.
print("Letra B\n", notas[1][2])

#c) Altere a nota da 1ª prova do 3º aluno para 6.8.
notas[2][0] = 6.8
print("Letra C\n", notas[2][0])

#d) Altere a nota da 4ª prova do 5º aluno para 5.6.
notas[4][3] = 5.6
print("Letra D\n", notas[4][3])

print("\nQuestão 3")
#a) Exiba todos as notas do 1ª aluno.
for n in range(4):
    print("Letra A\n", notas[0][n])
    
#b) Exiba todos as notas do 4ª aluno.
for n in range(4):
    print("Letra B\n", notas[3][n])

#c) Exiba todas as notas da 2ª prova.
for n in range(5):
    print("Letra C\n", notas[n][1])
    
#d) Exiba todas as notas da 4ª prova.
for n in range(5):
    print("Letra D\n", notas[n][3])

#e) Exiba todas as notas da turma.
for n in range(5):
    print("Letra E\n", notas[n])

print("\nQuestão 4")
#Considerando que a matriz da questão 1 representa as notas de uma
#a) Calcule a média do 2º aluno da turma.

soma = 0

for n in range(4):
    soma = soma + notas[1][n]

media = soma / len(notas[1])

print("Letra A\n", media)

#b) Calcule a media da turma (formada pela media de todas as notas).
soma = 0

for l in range(len(notas)):
    for c in range(len(notas[l])):
        soma = soma + notas[l][c]

media = soma / (len(notas)*4)

print("Letra B\n", media)

#c) Exiba a menor nota do 3ª aluno
menor = notas[2][0]

for n in notas[2]:
    if n < menor:
        menor = n
print("Letra C\n", menor)

#d) Informe a média de todos alunos da turma.
print("Letra D")

aluno = 1

for n in range(len(notas)):
    media = 0
    print("Média do aluno", aluno)
    for l in range(len(notas[n])):
        media = media + notas[n][l]
    print(media / len(notas[0]))
    aluno = aluno + 1
