nomes = []

nomes.append("Iure")
nomes.append("Ianca")
nomes.append("Esdras")

print("O ultimo elemento da lista é:", nomes[len(nomes)-1])