notas = []

for nota in range(10):
    nota = float(input("Digita a sua nota: "))
    notas.append(nota)
print("Foram inseridas", len(notas), "notas" )