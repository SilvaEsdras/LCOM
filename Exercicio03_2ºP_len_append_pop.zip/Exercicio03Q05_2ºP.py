numeros = [36, 37, 38, 39, 40]

#a) Retire o primeiro elemento da lista e exiba (percorrendo a lista) todos seus elementos.
#print("Retirando o primeiro elemento, lista atual é:", numeros)
#numeros.pop(0)

#for elemento in range(len(numeros)):
#    print(numeros[elemento])

#b) Retire o último elemento da lista e percorra a lista exiba todos os seus elementos.
print("Retirando o último elemento, lista atual é:", numeros)
numeros.pop(-1)

for elemento in range(len(numeros)):
    print(numeros[elemento])

#OBS: Precisei comentar a letra A pra poder roda a letra B sem erros rs :)