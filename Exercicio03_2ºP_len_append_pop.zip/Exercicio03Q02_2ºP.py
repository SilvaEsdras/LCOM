#Crie uma lista com 2 elementos e, após a sua criação, adicione mais 2
#elementos a lista. Por fim, exiba a lista final.
numeros = [36, 21]

numeros.append(18)
numeros.append(11)

print(numeros)