#Crie uma lista com 10 números e, utilizando a função len, faça:
lista = [20, 19, 18, 17, 16, 15, 14, 13, 12, 11]

#a) Exiba a quantidade de elementos da lista (tamanho da lista)
print("O tamnho da sua lista é:", len(lista))

#b) Exiba o último elemento da lista.
numero = len(lista)
print("O último elemento é:", lista[-1])

#c) Exiba o penúltimo elemento da lista,
numero = len(lista)
print("O peúltimo elemento é:", lista[-2])

#d) Exiba o antepenúltimo elemento da lista
numero = len(lista)
print("O antepeúltimo elemento é:", lista[-3])

#e) Percorra a lista exibindo cada um de seus elementos.
print("Exibindo cada elemento da lista") 
for elemento in range(len(lista)):
    print(lista[elemento])
#f) Percorra a lista acrescentado 1 aos seus elementos. Ou seja,
#somando os elementos da lista com 1 e adicionado o resultado
#novamente ao elemento somado.
soma = 0

print("Exibindo cada elemento com um acresimo de 1:")
for elemento in range(len(lista)):
    soma = lista[elemento] + 1
    print(soma)
