nota1 = float(input("Qual foi a sua primeira nota: "))
nota2 = float(input("Qual foi a sua segunda nota: "))
nota3 = float(input("Qual foi a sua terceira nota: "))

media = (nota1 + nota2 + nota3) / 3

print(f' Sua média foi: {media}')