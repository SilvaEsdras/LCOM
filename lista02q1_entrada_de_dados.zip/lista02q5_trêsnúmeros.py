a = int(input("Digite um número inteiro: "))
b = int(input("Digite outro número inteiro: "))
c = int(input("Digite mais um número inteiro: "))

x = (a + b)*2 / 2 + (b + c) / 2

print(f'Valor de a: {a} \nValor de b: {b} \nValor de c: {c} \nValor de x: {x}')